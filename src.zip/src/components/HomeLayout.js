import logo from "../images/Logo.png";
import React, {useState} from "react";
import NaviBar from "./NaviBar";

import {Layout} from 'antd';
import Mailbox from "./Mailbox";

const { Header, Content, Footer } = Layout;

const HomeLayout: React.FC = () => {

    const [mailboxOpen,setMailboxOpen] = useState(false)
    function openMailbox(){
        setMailboxOpen(true);
    }

    const goHome = () => {
        window.location.href = `/home`;
    }

    return (
        <div>
            <Layout className="layout">
                <Header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', backgroundColor: 'white', width: '100%' }}>
                    <img src={logo} className={"naviLogo"} onClick={goHome}/>
                    <NaviBar style={{ marginLeft: 'auto' }} openMailbox={openMailbox}/>
                </Header>
                <Mailbox trigger={mailboxOpen} setTrigger={setMailboxOpen}/>
            </Layout>

        </div>


);
};

export default HomeLayout;