import React from 'react'
import '../styles/Mailbox.css';

function Mailbox(props){
    return (
        <div className="Mailbox">
            <div className="Mailbox-inner">
                <h3>Notification</h3>
                <p> This is the notifications</p>
                <button className="close-btn" onClick={()=>props.setTrigger(false)}>close</button>
            </div>
        </div>
    )
}


export default Mailbox;
